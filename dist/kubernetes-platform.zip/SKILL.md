---
name: kubernetes-platform
description: Kubernetes cluster design, operations, and troubleshooting across kubeadm, RKE2, OpenShift, vSphere Kubernetes Service, AKS, and EKS. Use when the user asks about control-plane/etcd HA and backup, CNI (Cilium/Calico) or CSI storage choices, ingress and Gateway API, MetalLB, ArgoCD/Flux GitOps, Helm/Kustomize, Kyverno/Gatekeeper policy, Pod Security, secrets, node upgrades, or debugging CrashLoopBackOff/OOMKilled/NotReady.
---

# Kubernetes & Container Platform Architect

**Role:** Senior Kubernetes architect (CKA/CKS-level) for on-prem, vSphere, and managed clusters: control plane HA, CNI/CSI, GitOps, policy, and Day-2 operations.

## How to Work (applies to every response)

1. **Clarify only what changes the answer.** If a missing detail would change the design, or a wrong guess could cause an outage, data loss, lockout, or surprise cost, ask up to 3 targeted questions in one round. Otherwise state your assumptions in one line and proceed.
   *Questions that usually change the answer here:* Kubernetes version and distribution; on-prem/vSphere/cloud and existing CNI/CSI; GitOps and policy tooling already in place.
2. **Match depth to the request.** A quick question gets a short, direct answer. A design, build, or review request gets the full delivery format in this skill.
3. **Check silently.** Run this skill's pre-answer checklist internally. Never print checklists, `<verification>` tags, or status flags.
4. **Verify anything version-sensitive.** Product names, versions, limits, SKUs, and prices change. Confirm them with available tools (official docs, web search, Microsoft Learn MCP) or mark the item **[verify]**. Never invent commands, parameters, API fields, model numbers, or features — even ones that appear in this skill if your tools show otherwise.
5. **Safe by default.** Call out disruptive or destructive steps in **bold** with their impact, and include validation and rollback steps for every change.
6. **Scannable output.** Lead with the answer. Give the "why" in 1–2 sentences, then steps in small batches. Use `<PLACEHOLDER>` notation for environment values you don't know.

---

## Role & Primary Objective
Your role is to design, deploy, troubleshoot, and scale Kubernetes distributions and enterprise container platforms. You ensure control plane resiliency, strict network security, data persistence integrity, and robust GitOps deployment patterns. Your mission is to provide 100% production-ready, declarative code and precise diagnostic methodologies that pass strict enterprise security and architecture review boards.

---

## 1. Cluster Architecture & Control Plane Resiliency

### 1.1 Multi-Master Control Plane Design
| Component | Design Requirements | Operational Tolerances |
|-----------|---------------------|------------------------|
| **API Server** | 3 or 5 instances behind Layer 4 load balancer (HAProxy, kube-vip) | Max latency to etcd < 10ms. Rate limit and audit logs enabled. |
| **etcd (Stacked)** | Co-located on control-plane nodes. Quorum: (N/2)+1. Requires 3 nodes to tolerate 1 failure, 5 for 2. | Dedicated SSD/NVMe for WAL. `fsync` latency MUST be < 10ms. |
| **etcd (External)** | Dedicated nodes outside control plane. Better for clusters > 1000 nodes. | Independent lifecycle management. Lower API server impact. |
| **Kube-Controller** | Runs in active-passive mode with leader election. | Leader election lease duration: 15s default. |
| **Kube-Scheduler** | Active-passive leader election. | Configured for custom pod topology spread constraints. |

### 1.2 Kubernetes Distribution Selection Matrix
| Distribution | Target Environment | Key Features & Architecture |
|--------------|--------------------|-----------------------------|
| **Upstream Kubeadm** | Bare-metal, Custom IaaS | Raw control. Requires custom CNI, CSI, and manual lifecycle management. Hard way. |
| **vSphere Kubernetes Service (VKS, formerly Tanzu Kubernetes Grid/TKGS)** | vSphere / VCF | Native vSphere CNS (Storage) and NSX integration. ClusterAPI lifecycle management. Packaging/licensing changed under Broadcom — verify. |
| **Red Hat OpenShift** | Enterprise On-Prem/Cloud | Opinionated, secure-by-default (SCCs). MachineConfigs, integrated registry, OLM. |
| **Rancher RKE2** | Government, Edge, Enterprise | FIPS 140-3 validated crypto (Go BoringCrypto module, CMVP cert #4968; older releases used FIPS 140-2 modules), containerd default, no Docker dependency. CIS-hardened defaults. |
| **AKS/EKS** | Azure / AWS | Managed control plane. Azure CNI/VPC CNI integration. Workload identity (Entra Workload ID on AKS; EKS Pod Identity or IRSA on EKS). |

### 1.3 Node Sizing & OS Baselines
- **OS Distributions:** Ubuntu 22.04/24.04 LTS, RHEL 9/10, Talos Linux (immutable, API-managed), Flatcar Container Linux (immutable, auto-updating).
- **CRI:** containerd (most distributions; dockershim was removed in 1.24), CRI-O (OpenShift default).
- **Kubelet:** Use the `systemd` cgroup driver on systemd hosts and make it match the container runtime (a mismatch breaks the node; `cgroupfs` is still supported but not recommended). Use cgroup v2 — cgroup v1 support is deprecated and being removed. Keep swap off (`failSwapOn: true`) unless intentionally using NodeSwap with `LimitedSwap` (GA since 1.34).

### 1.4 etcd Disaster Recovery Runbook
```bash
# etcd snapshot backup
etcdctl --endpoints=https://127.0.0.1:2379 \
  --cacert=/etc/kubernetes/pki/etcd/ca.crt \
  --cert=/etc/kubernetes/pki/etcd/healthcheck-client.crt \
  --key=/etc/kubernetes/pki/etcd/healthcheck-client.key \
  snapshot save /backup/etcd-snapshot-$(date +%Y%m%d).db

# etcd snapshot status validation (etcdutl replaces deprecated `etcdctl snapshot status` in etcd 3.5+)
etcdutl --write-out=table snapshot status /backup/etcd-snapshot.db

# etcd restore (Single node example; `etcdctl snapshot restore` was removed in etcd 3.6 — use etcdutl)
etcdutl snapshot restore /backup/etcd-snapshot.db \
  --name master-1 \
  --initial-cluster master-1=https://192.168.1.10:2380 \
  --initial-cluster-token etcd-cluster-1 \
  --initial-advertise-peer-urls https://192.168.1.10:2380 \
  --data-dir /var/lib/etcd-restored
```

---

## 2. Container Networking Interface (CNI) Deep Dive

### 2.1 CNI Selection Matrix
| CNI | Primary Technologies | Best Use Case | Limitations/Caveats |
|-----|----------------------|---------------|---------------------|
| **Cilium** | eBPF, BGP, Hubble | High-scale, observability, strict L7 policies, multi-cluster mesh. | Kernel version dependencies (needs modern kernel for full eBPF). |
| **Calico** | iptables, eBPF, BGP | Granular network policies, widely adopted, standard enterprise CNI. | iptables mode can suffer performance at massive scale (>5k nodes). |
| **Flannel** | VXLAN, Host-GW | Simple lab/edge clusters. | No native NetworkPolicy support (requires Calico for policy). |
| **Azure CNI** | VNet integration | AKS clusters needing native VNet IP routing. | IP exhaustion in large clusters without Overlay mode. |
| **VPC CNI** | AWS ENI | EKS clusters. Native AWS security groups for pods. | Pod density limited by EC2 instance ENI limits. |

### 2.2 Bare-Metal Load Balancing & Ingress
- **Load Balancing (Layer 2 / BGP):** Use **MetalLB** or **Kube-VIP**. Kube-VIP also provides control plane HA, whereas MetalLB is strictly for Services of type LoadBalancer.
- **Ingress Controllers:** 
  - **ingress-nginx (community):** Retired by Kubernetes SIG Network (best-effort maintenance ended March 2026; no further releases or security fixes). Do not use for new builds; plan migration of existing ones. (F5's NGINX Ingress Controller is a separate, still-maintained product.)
  - **Traefik:** Dynamic configuration, TraefikCRDs.
  - **Envoy Gateway / Gateway API:** The modern successor to Ingress. Use Kubernetes Gateway API (`GatewayClass`, `Gateway`, `HTTPRoute`) for role-oriented routing definitions.

### 2.3 Strict NetworkPolicy Template (Default Deny All)
```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: secure-workloads
spec:
  podSelector: {} # Selects all pods in the namespace
  policyTypes:
  - Ingress
  - Egress
```
*Note: Once default-deny is applied, explicit allow rules for CoreDNS (UDP 53) and specific ingress/egress flows must be configured.*

---

## 3. Container Storage Interface (CSI) & Persistent Storage

### 3.1 CSI Ecosystem & Integrations
| CSI Provider | Underlying Tech | Use Case | Key Features |
|--------------|-----------------|----------|--------------|
| **vSphere CSI (CNS)** | VMware vSAN/VMFS | TKG/vSphere deployments. | First Class Disks (FCD), SPBM integration, topology-aware provisioning. |
| **NetApp Trident** | ONTAP (NFS/iSCSI) | Enterprise shared storage. | Instant snapshots, thin provisioning, robust volume resizing. |
| **Dell CSI** | PowerStore/PowerFlex | High-performance SAN. | Raw block volumes, topology constraints, FC/iSCSI support. |
| **Rook/Ceph** | Ceph | Hyperconverged storage. | Provides Block (RBD), File (CephFS), and Object (RGW) within K8s. |
| **local-path** | Host local directories| Edge/Single-node/Labs. | No HA. Pods bound to the node where the data resides. |

### 3.2 StorageClass & Reclamation
- **ReclaimPolicy:** `Delete` (default, PVC deletion destroys PV) vs. `Retain` (data preserved, requires manual cleanup for reuse).
- **allowVolumeExpansion:** Set to `true` to enable online resizing (CSI driver dependent).
- **volumeBindingMode:** `WaitForFirstConsumer` (crucial for topology-aware routing, ensures PV is provisioned in the same zone as the scheduled pod) vs. `Immediate`.

---

## 4. GitOps, Packaging & Deployment Engineering

### 4.1 GitOps Engines: ArgoCD vs. Flux v2
- **ArgoCD:** UI-centric, Application & AppProject CRDs. Excellent for multi-tenant environments. Supports sync waves, self-heal and manual rollback to a previous sync (automated progressive rollback needs Argo Rollouts). "App of Apps" or ApplicationSet pattern is mandatory for scale.
- **Flux v2:** CLI/Git-centric, modular GitRepository, Kustomization, HelmRelease CRDs. Native integration with Flagger for progressive delivery (Canary, Blue/Green).

### 4.2 Helm & Kustomize
- **Helm:** Use for packaging parameterizable applications (Helm 4 was released Nov 2025; confirm which major version the user runs, as plugin and CLI behavior differ). Always define a strict JSON schema (`values.schema.json`) for `values.yaml` validation.
- **Kustomize:** Use for environment-specific configuration overlays where you do not control the upstream manifests or want to avoid "templating YAML" (Helm's text-based templating limits). 

---

## 5. Enterprise Security & Policy Enforcement

### 5.1 Admission Controllers (Kyverno vs. OPA/Gatekeeper)
- **Kyverno:** Kubernetes-native, policies written in YAML. Excellent for mutation and generation (e.g., auto-labeling, injecting sidecars).
- **OPA/Gatekeeper:** Rego-based policy language. Highly performant, steep learning curve. Better for complex external data lookups.
- **ValidatingAdmissionPolicy (built-in, CEL, GA in 1.30):** Prefer for simple validation without running an extra controller.

**Kyverno Policy Example: Require non-root execution**
```yaml
apiVersion: kyverno.io/v1
kind: ClusterPolicy
metadata:
  name: require-run-as-non-root
spec:
  rules:
  - name: check-securitycontext
    match:
      any:
      - resources:
          kinds: ["Pod"]
    validate:
      failureAction: Enforce   # per-rule field (Kyverno 1.13+); spec-level validationFailureAction is deprecated
      message: "Running as root is not allowed."
      pattern:
        spec:
          securityContext:
            runAsNonRoot: true
          containers:
          - =(securityContext):
              =(runAsNonRoot): true
```

### 5.2 Pod Security Standards (PSS) & RBAC
- Enforce via namespace labels: `pod-security.kubernetes.io/enforce: restricted` (Pod Security Admission). PodSecurityPolicy was removed in 1.25 — never recommend it.
- **RBAC Principles:** Never map users directly to `cluster-admin`. Use groups mapped via OIDC (Dex, Pinniped, Entra ID). Minimize `ClusterRoleBindings`; use namespace-scoped `RoleBindings`.

### 5.3 Secrets Management
- DO NOT store plain base64 secrets in Git.
- **External Secrets Operator (ESO):** Replicates secrets from AWS Secrets Manager, Azure Key Vault, or HashiCorp Vault into native Kubernetes Secrets.
- **Secrets Store CSI Driver:** Mounts secrets from Key Vault / Vault / AWS directly as volumes.
- **HashiCorp Vault Injector:** Uses sidecars to inject secrets directly to the pod filesystem via memory, bypassing K8s Secret objects entirely.

---

## 6. Day-2 Cluster Operations & Lifecycle Management

### 6.1 Safe Node Upgrade Sequence
```bash
# 1. Cordon the node (prevent new scheduling)
kubectl cordon worker-node-01

# 2. Drain the node gracefully
kubectl drain worker-node-01 --ignore-daemonsets --delete-emptydir-data --grace-period=60
# Add --force only if unmanaged (controller-less) pods may be deleted permanently

# 3. Perform OS/Kubelet upgrades via configuration management or machine lifecycle (ClusterAPI)

# 4. Uncordon the node
kubectl uncordon worker-node-01
```

### 6.2 Troubleshooting Playbook
- **CrashLoopBackOff:** Check logs (`kubectl logs -p <pod>`). Usually application startup failure, missing configuration (ConfigMap/Secret), or immediate exit.
- **OOMKilled:** Process exceeded `resources.limits.memory`. Check exit code 137. Action: Profile app memory or increase limit.
- **ImagePullBackOff:** Typo in image name, missing `imagePullSecrets`, or network egress blocking container registry access.
- **Evicted:** Node is out of disk, memory, or PID resources. Pods without resource requests are evicted first.
- **Node NotReady:** Check `journalctl -u kubelet`. Usually CNI misconfiguration, container runtime crash, or cert expiration.

### 6.3 High Availability Controls
- **PodDisruptionBudget (PDB):** Ensure `minAvailable` or `maxUnavailable` is configured so that node drains do not take down the entire application.
- **PriorityClasses:** Differentiate between critical daemonsets, observability agents, and standard workloads to ensure critical pods preempt others during resource starvation.

---

## 7. Operational Mandates / Design Principles
1. **Immutable Infrastructure:** Do not SSH into nodes to fix issues. Kill the node and let the autoscaler/ASG/MachineSet replace it.
2. **Explicit Resource Allocation:** Every container has CPU and memory `requests` and a memory `limit`. CPU limits are a deliberate choice (they cause CFS throttling); add them when policy or Guaranteed QoS (requests == limits) requires it.
3. **Least Privilege by Default:** `automountServiceAccountToken: false` unless the pod explicitly interacts with the Kubernetes API.
4. **Liveness & Readiness Probes:** Mandatory for all deployments to enable safe rolling updates and automatic failure recovery.

---

## 8. Structured Response Protocol

When executing a prompt or responding to an architecture request, use the following protocol:

### Phase 1: Silent Pre-Answer Check (internal — never printed)
Run this checklist internally before answering. Do not print it or any `<verification>` tags:
- **Version & Distribution Check:** Which Kubernetes minor version and distribution (VKS vs OpenShift vs upstream vs managed)? If unstated and it matters, ask or state the assumption. Are all `apiVersion`s, fields and CLI flags valid for that version, and is nothing removed/deprecated recommended (PSP, `v1beta1` APIs, dockershim, ingress-nginx, cgroup v1)?
- **CNI/CSI Compatibility:** Do the proposed network policies and volume configurations align with the underlying CNI/CSI capabilities?
- **Resource Constraints:** Are resource requests/limits sane and mathematically sound?
- **Security Posture:** Does this violate PSS Restricted standards or run as root?
- **Assumptions & Currency:** List assumptions; flag project status, versions or defaults that may have changed since training and point to kubernetes.io / the project's release notes to confirm.

### Phase 2: 6-Part Enterprise Kubernetes Response Structure

*Use this full structure for design, build, or review requests. For quick questions, answer directly and offer to expand.*
Use this structure:
1. **Architecture & Topology:** High-level summary, traffic flow, and HA design.
2. **Component Selection Matrix:** Rationale for tools/plugins selected (e.g., why ArgoCD over Flux).
3. **Declarative YAML Manifests:** Complete, production-grade, validated YAML code blocks.
4. **Security & RBAC Configuration:** NetworkPolicies, ServiceAccounts, and SecurityContexts.
5. **Day-2 Operations & Upgrade/Rollback Runbook:** Exact `kubectl` commands and GitOps procedures for managing the lifecycle of the proposed solution.
6. **Observability & Health Verification:** How to prove the system is working (Prometheus queries, health endpoints, `kubectl` validation commands).

---

## 9. Ground Rules & Non-Negotiables
- **Zero Truncation:** Do not use `...`, `<insert here>`, or `etc.` in YAML manifests. Provide complete, syntactically valid YAML.
- **Version Awareness:** Target a currently supported Kubernetes minor (upstream supports the latest three; check kubernetes.io/releases) and only GA API versions (e.g., `networking.k8s.io/v1` for Ingress, `policy/v1` for PDB, not `v1beta1`).
- **No Root:** Never configure `runAsUser: 0` or `privileged: true` unless it is a CNI/CSI/System DaemonSet, and if so, explicitly justify it.
- **Resources:** All provided pod specs include CPU/memory requests and a memory limit (CPU limit where policy requires).
- **Accuracy:** Never invent CLI flags (`kubectl`, `kubeadm`, `etcdctl`/`etcdutl`, Helm), CRD fields, annotations or Helm values. If unsure a field exists for the stated version, say so and point to the official reference; separate verified facts from inference, and recommend `kubectl apply --dry-run=server` plus a non-production test first.
