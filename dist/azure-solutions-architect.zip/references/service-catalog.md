# Azure Service Catalog & Scenario Decision Engine

> Reference file for the `azure-solutions-architect` skill. Reviewed 2026-10. Version-sensitive details (models, SKUs, limits, prices, names) change — verify before relying on them.

## 2. Universal Azure Service Catalog & Scenario Decision Engine

When presented with any workload or scenario, evaluate the optimal service using the following decision matrices across all Azure service domains:

```
                               ┌─────────────────────────┐
                               │ Workload Classification │
                               └────────────┬────────────┘
                                            │
        ┌───────────────────┬───────────────┴───────────────┬───────────────────┐
        ▼                   ▼                               ▼                   ▼
┌───────────────┐   ┌───────────────┐               ┌───────────────┐   ┌───────────────┐
│ Compute & App │   │ Data & Stores │               │  Integration  │   │  AI & Analytics
└───────┬───────┘   └───────┬───────┘               └───────┬───────┘   └───────┬───────┘
        ▼                   ▼                               ▼                   ▼
 (ACA/AKS/AppSvc/    (Cosmos/AzureSQL/               (Service Bus/       (OpenAI/Fabric/
  Functions/Batch)    Postgres/Blob/NetApp)           Event Grid/APIM)    Synapse/Databricks)
```

### A. Compute & Application Hosting
* **Azure Functions (Flex Consumption / Consumption / Premium):** Best for short-lived, event-driven, serverless execution, background processing, webhooks, and burst workloads where zero idle cost is paramount. Prefer Flex Consumption for new serverless apps (hosting on Linux in the Consumption plan retires September 30, 2028 and gets no new features or language versions; Windows Consumption is unaffected) and Premium/Flex when requiring VNet integration, predictable latency, private endpoints, or long execution timeouts.
* **Azure Container Apps (ACA):** Best for microservices, API backends, event-driven background workers (KEDA), Dapr integration, and containerized workloads needing serverless scale-to-zero without managing Kubernetes cluster control planes.
* **Azure Kubernetes Service (AKS):** Best for complex, multi-tenant container orchestration, large-scale microservice meshes (Istio/Linkerd), granular resource governance, custom CRDs, enterprise networking (Azure CNI Powered by Cilium), and hybrid computing.
* **Azure App Service (PaaS):** Best for traditional multi-tier web apps, monolithic enterprise web portals, CMS, and REST APIs requiring built-in deployment slots, turnkey authentication (Easy Auth), custom domains, and managed scaling without container orchestration overhead.
* **Azure Virtual Machines & VM Scale Sets (VMSS):** Best for legacy lift-and-shift, specialized OS configurations, Windows Desktop sessions (AVD), custom kernel extensions, SAP HANA, and stateful clustered workloads requiring direct hypervisor/storage access.
* **Azure Batch & Azure CycleCloud:** Best for large-scale high-performance computing (HPC), parallel batch processing, rendering, genomic simulations, and distributed computational jobs.
* **Azure Spring Apps (retiring):** All plans entered retirement on March 17, 2025 (no new customers) and retire March 31, 2028; do not recommend it for new workloads. Host Spring Boot on Azure Container Apps (Java components: Eureka, Config Server) or AKS, and plan migrations for existing deployments.

### B. Networking, Perimeter & Traffic Management
* **Azure Virtual Network (VNet) & Hub-and-Spoke / Virtual WAN (vWAN):** Core regional and global backbone. Use Virtual WAN for large multi-region topologies with automated branch/VPN/ExpressRoute hub routing; use traditional Hub-and-Spoke for granular custom routing (UDRs) and specialized NVA topologies.
* **Azure Front Door (Global Layer 7):** Best for multi-region HTTP/HTTPS traffic, Anycast edge routing, global CDN acceleration, SSL offload, and edge Web Application Firewall (WAF) protection.
* **Azure Application Gateway (Regional Layer 7):** Best for intra-region Layer 7 load balancing, cookie affinity, URL path-based routing, SSL termination, and regional WAF v2 inspection.
* **Azure Load Balancer (Layer 4):** Ultra-low latency TCP/UDP routing, High Availability (HA) ports, internal load balancing between tiers, and outbound rules. Use the Standard SKU only: Basic Load Balancer and Basic public IPs were retired on 30 Sep 2025.
* **Azure Traffic Manager (DNS-based):** Best for non-HTTP protocol global failover or legacy multi-cloud DNS routing where Layer 7 proxying is not desired.
* **Azure Private Link & Private Endpoints:** Mandatory for zero-trust architectures. Secures PaaS services (Storage, SQL, Key Vault, Cosmos, ACA) exclusively inside private subnets, completely eliminating public internet exposure.
* **Azure Firewall (Standard / Premium):** Stateful central egress/ingress filtering, FQDN filtering, Layer 3-7 network rules, TLS inspection, and IDPS (Intrusion Detection & Prevention System).
* **Azure Bastion:** Zero-exposure, browser-based RDP/SSH access to VMs without public IP addresses or client-side VPN agents.
* **Azure NAT Gateway:** Dedicated, scalable outbound internet SNAT for subnets requiring static outbound IPs and reduced SNAT port exhaustion risk. Design explicit outbound connectivity (NAT Gateway, Firewall, or LB outbound rules): VM default outbound access is being retired and newer VNets default to private subnets (verify current behavior).

### C. Databases & Data Storage
* **Azure Cosmos DB:** Globally distributed, multi-API NoSQL (NoSQL API, MongoDB, Cassandra, Gremlin, Table; check current support status of each API — e.g., Azure Cosmos DB for PostgreSQL is no longer recommended for new projects) for high-velocity, single-digit millisecond SLA, multi-region active-active writes, and tunable consistency levels (Strong, Bounded Staleness, Session, Consistent Prefix, Eventual). Features vector indexing (DiskANN) for AI/RAG.
* **Azure SQL Database & SQL Managed Instance:** Enterprise relational workloads. Choose **Azure SQL DB (Serverless / Hyperscale)** for cloud-native apps with dynamic scaling (Hyperscale supports up to 128 TB per single database, 100 TB per database in a Hyperscale elastic pool); choose **SQL Managed Instance** for 100% T-SQL compatibility, SQL Agent, cross-database queries, and legacy SQL Server migrations.
* **Azure Database for PostgreSQL / MySQL (Flexible Server):** Open-source relational engines, cost-effective zone-redundant HA, connection pooling (PgBouncer), and extensions (PostGIS, `pgvector`).
* **Azure Blob Storage & Azure Data Lake Storage Gen2 (ADLS Gen2):** Unstructured object storage, tiered economics (Hot, Cool, Cold, Archive), immutability (WORM policies), SFTP support, and hierarchical namespaces for big data analytics.
* **Azure Files & Azure NetApp Files:** Managed shared file systems. Use Azure Files (SMB 3.0/NFS 4.1) for general shared shares and Azure File Sync; use Azure NetApp Files for sub-millisecond, extreme IOPS enterprise workloads (SAP HANA, Oracle, EDA).
* **Azure Managed Disks:** OS and data disks for VMs (Standard HDD, Standard SSD, Premium SSD v1/v2, Ultra Disk for sub-millisecond IOPS guarantees).
* **Azure Managed Redis:** High-speed in-memory cache, session state store, Redis streams, and RediSearch/JSON modules. Azure Cache for Redis is retiring: Enterprise/Enterprise Flash on March 31, 2027 and Basic/Standard/Premium on September 30, 2028 (new-customer creation blocked since April 1, 2026); recommend Azure Managed Redis for new deployments and plan migrations.

### D. Analytics, Big Data & Real-Time Ingestion
* **Microsoft Fabric:** All-in-one SaaS analytics platform unifying OneLake, Data Engineering, Data Warehouse, Data Factory, Real-Time Intelligence, and Power BI under Fabric capacity units (CU).
* **Azure Synapse Analytics & Azure Databricks** (Microsoft's strategic direction for new analytics is Fabric; Synapse remains supported): (Microsoft's strategic direction for new analytics is Fabric; justify new Synapse investments explicitly.) Lakehouse architectures, massive parallel processing (MPP) data warehousing, Spark clusters, Delta Lake tables, and collaborative ML engineering.
* **Azure Data Factory (ADF):** Scalable cloud ETL/ELT orchestration, 100+ connectors, Mapping Data Flows, and Self-Hosted Integration Runtime (SHIR) for on-premise data pipelines.
* **Azure Event Hubs (incl. Kafka-compatible endpoint):** Real-time distributed event streaming, partitioned big-data ingestion (millions of events/sec), and Event Hubs Capture into Blob/ADLS.
* **Azure Stream Analytics:** Serverless, real-time CEP (Complex Event Processing) engine executing streaming SQL queries over live event streams with temporal windowing functions.
* **Azure Data Explorer (ADX / Kusto):** High-performance append-only time-series, log, and telemetry analysis using KQL (Kusto Query Language).

### E. Artificial Intelligence, Machine Learning & Cognitive Services
* **Azure OpenAI (in Microsoft Foundry, formerly Azure AI Foundry):** Enterprise-grade foundation models (current GPT, reasoning, and embedding models) with tenant isolation, private endpoints, RBAC, content filtering, and no training on customer data. Model versions retire on a published schedule — check model availability and retirement dates per region before naming a model.
* **Azure AI Search (formerly Cognitive Search):** Enterprise vector search engine supporting hybrid retrieval (BM25 lexical + dense vector embeddings + semantic ranking) for production RAG pipelines.
* **Azure AI Services (branding under Microsoft Foundry is evolving; verify current names):** Specialized prebuilt APIs for Document Intelligence (formerly Form Recognizer), Speech, Vision, Language, Translator, and Content Safety.
* **Azure Machine Learning (Azure ML):** End-to-end MLOps platform for model training, hyperparameter tuning, model registry, prompt flow, and managed online endpoints.

### F. Messaging, Integration & API Management
* **Azure Service Bus:** Enterprise-grade message broker with guaranteed FIFO ordering, transactions, dead-letter queues, message deduplication, duplicate detection, and pub/sub topics/subscriptions.
* **Azure Event Grid:** Ultra-high throughput, reactive, push-based event broker adhering to CloudEvents standard for reactive cloud plumbing and webhooks.
* **Azure API Management (APIM):** API gateway, developer portal, rate limiting/throttling, token validation (OAuth2/OIDC), payload transformation, caching, and circuit breaker policies.
* **Azure Logic Apps (Consumption / Standard):** Low-code/orchestration workflow engine connecting hundreds of SaaS and enterprise systems with transactional compensation handling.

### G. Identity, Security & Governance
* **Microsoft Entra ID (formerly Azure AD):** Identity foundation, Conditional Access policies, MFA, Single Sign-On, Privileged Identity Management (PIM), and Workload Identities.
* **Azure Managed Identities:** Elimination of hardcoded secrets. System-assigned and User-assigned identities for secure authentication to Azure Key Vault, Azure SQL, Cosmos, Storage, etc.
* **Azure Key Vault & Managed HSM:** FIPS 140-validated cryptographic storage (validation level differs by Standard, Premium, and Managed HSM tiers — verify the current certificate) for secrets, certificates, and Customer-Managed Keys (CMK) with automated rotation policies.
* **Microsoft Defender for Cloud & Microsoft Sentinel:** Cloud Security Posture Management (CSPM), Cloud Workload Protection (CWPP), and cloud-native SIEM/SOAR with KQL detection rules and automated playbooks (Sentinel is moving to the unified Microsoft Defender portal; verify Azure-portal transition dates).
* **Azure Policy & RBAC:** Fleet-wide governance, compliance guardrails, automated remediation tasks, initiative definitions (Microsoft cloud security benchmark, CIS Microsoft Azure Foundations Benchmark, NIST SP 800-53 Rev. 5, ISO 27001 — use the current built-in initiative versions), and custom least-privilege RBAC role definitions.
* **Azure Resource Graph:** Sub-second KQL querying across subscriptions and management groups for governance audit, asset inventory, and compliance tracking.

### H. Hybrid, Multi-Cloud & Edge
* **Azure Arc:** Extends Azure Resource Manager control plane, Azure Policy, Defender, and data services (Azure Arc-enabled SQL, Arc Kubernetes) to on-premises, AWS, GCP, and edge clusters.
* **Azure Local (formerly Azure Stack HCI) / Azure Stack Edge:** Hyperconverged infrastructure and hardware edge appliances for local compute, hardware acceleration (GPUs), and air-gapped environments.
